# tdm_api_for_sigma_ui


### Description

This script gets new sigma rules after late 30 days for current now date. Default script get all sigma rules for all 
platforms or other filtering parameters after save dir 'output' nested dir when save script file, format file be '*.json'.
If you want more option settings you can use console command.


#### Warning: this scpirt works with python3.6 version or higher

Check the version of your python
```shell
$ python -V
```

Install packages:
* run command:
```shell
pip install -Ur requirements.txt
```

To simple base option run this script, you need:
* add the API_KEY variable
* run command:
```shell
python tdm_api_for_sigma_ui.py -k XXXXXXXXXXXXX
```

##### You can use console command, for comfortable to you.
run command:
```shell
usage: tdm_api_for_sigma_ui.py [-h] [--debug-mode [DEBUG_MODE]] [-d PATH_DIR]
                               [-k API_KEY] [-s STARTDATE] [-v {sigma}]

List commands for "tdm_api_for_sigma_ui.py" script.

optional arguments:
  -h,                 --help                          show this help message
  -d PATH_DIR,       --path-dir PATH_DIR              full path to directory
  -k API_KEY,        --api-key API_KEY                secret api key
  -s STARTDATE,      --startdate STARTDATE            the start date - format: YYYY-MM-DD
  -v {sigma},        --filter-siem-type {sigma}       filter siem type
  -m MAPPING_FIELD,  --mapping-field MAPPING_FIELD    get sigma mapping field rule
                     --debug-mode [DEBUG_MODE]        activate debug mode in console
```
