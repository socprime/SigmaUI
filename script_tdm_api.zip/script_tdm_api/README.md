# tdm_api_integration_tool

This script gets new sigma rules with datetime (format **%Y-%m-%dT%H:%M:%S**), example: "2018-04-20T00:00:00".

#### Warning: this scpirt works with python3.6 version or higher

Check the version of your python
```shell
$ python -V
```

To run this script, you need:
* add the API_KEY variable
* if you want search other datetime, change USE_DATETIME variable and remove the last_datetime.json file or use command
* run command:
```shell
python tdm_api_integration_tool.py
```

Install packages:
* run command:
```shell
pip install -Ur requirements.txt
```

##### You can use console command, for comfortable to use.
run command:
```shell
python tdm_api_integration_tool.py -h
usage: tdm_api_integration_tool.py [-h] [-d PATH_DIR] [-k API_KEY]
                                   [-s STARTDATE] [-m MAPPING_FIELD]


List commands for "tdm_api_integration_tool.py" script.

optional arguments:
  -h,                 --help                          show this help message and exit
  -d PATH_DIR,       --path-dir PATH_DIR              full path to directory
  -k API_KEY,        --api-key API_KEY                secret api key
  -s STARTDATE,      --startdate STARTDATE            the start date - format: YYYY-MM-DD
  -m MAPPING_FIELD,  --mapping-field MAPPING_FIELD    get sigma mapping field rule
```
