#!/usr/bin/env python3

__author__ = 'Andriy Yatsynyak'
__version__ = '2.0.2'
__company__ = 'SOC Prime'

import os
import argparse
import re
import datetime
import json
import logging
import logging.handlers
from time import sleep
import requests


DEBUG = False
BASE_DIR = os.path.dirname(os.path.realpath(__file__))
USE_DATETIME = ''

LAST_DATETIME = datetime.datetime.utcnow().replace(microsecond=0)
FIRST_DATETIME = LAST_DATETIME - datetime.timedelta(days=30)


BASE_URL = 'https://api.tdm.socprime.com/v1/'
PREFIX_SEARCH = 'search-sigmas'
PREFIX_MAPPING = 'custom-field-mapping'
MAX_ELEMENT_STORAGE_JSON = 7


RES_DIR = os.path.join(BASE_DIR, 'output')


USE_FILTER_CLIENT_SIEM_TYPE = None
FILTER_CLIENT_SIEM_TYPE = ['sigma']

API_KEY = ''
MAPPING = None
CACHE_FILE_DATETIME = os.path.join(BASE_DIR, 'last_datetime.json')


FRM_DATETIME = '%Y-%m-%dT%H:%M:%S'
KEY_DATE_END = 'date_end'
KEY_DATE_START = 'date_start'


class Logger:
    def __init__(self, logger_name):
        logging.captureWarnings(True)
        self.logger = logging.getLogger(logger_name)
        self.logger.setLevel(logging.INFO)

        self.logPath = BASE_DIR

        if not os.path.exists(self.logPath):
            self.logPath = os.path.dirname(os.path.abspath(__file__))

        LOG_FILENAME = os.path.normpath('{}/{}.log'.format(self.logPath, logger_name))

        fh = logging.handlers.RotatingFileHandler(LOG_FILENAME, maxBytes=5242880, backupCount=10)
        fh.setLevel(logging.INFO)
        fh.setFormatter(logging.Formatter('[%(asctime)s][%(name)s][%(levelname)s] %(message)s'))
        self.logger.addHandler(fh)

    def debug(self, msg):
        self.log(logging.DEBUG, msg)

    def info(self, msg):
        self.log(logging.INFO, msg)

    def warning(self, msg):
        self.log(logging.WARNING, msg)

    def error(self, msg):
        self.log(logging.ERROR,msg)

    def critical(self, msg):
        self.log(logging.CRITICAL, msg)

    def exception(self, msg):
        self.logger.exception(msg)

    def log(self, level, msg):
        msg = str(msg).replace('%', '')
        self.logger.log(level, str(msg) +' %s', '')


def pretty_print_requests(req, text):
    """
    At this point it is completely built and ready
    to be fired; it is "prepared".

    However pay attention at the formatting used in
    this function because it is programmed to be pretty
    printed and may differ from the actual request.
    """
    print('{}\n{}\r\n{}\r\n\r\n{}'.format(
        '-----------START-----------',
        req.method + ' ' + req.url,
        '\r\n'.join('{}: {}'.format(k, v) for k, v in req.headers.items()),
        text,
    ))


def query_api(logger, **kwargs):
    sleep_count = 0
    headers = {
       'client_secret_id': API_KEY
    }
    headers.update(**kwargs)
    url = f'{BASE_URL}{PREFIX_SEARCH}/'

    while True:
        try:
            response = requests.get(url, headers=headers)
            if DEBUG:
                req = requests.Request('GET', url, headers=headers)
                prepared = req.prepare()
                pretty_print_requests(prepared, response.text)
        except requests.exceptions.ConnectionError as e:
            logger.warning(f'some problem connect {e}')
            logger.info(f'connection refused by the server. {BASE_URL}')
            sleep(5)
            sleep_count += 1
            if sleep_count < 10:
                continue
            else:
                logger.error(f'failed connect for {sleep_count} iteration')
                return False, {}
        break

    if not response.ok:
        logger.error(f'response data: {response.status_code} '
                     f'{response.content} filter: {kwargs}')
        return False, response.json()
    else:
        return True, response.json()


def get_mapping_api(logger):
    headers = {
       'client_secret_id': API_KEY
    }

    response = requests.get(f'{BASE_URL}{PREFIX_MAPPING}/', headers=headers)
    if not response.ok:
        logger.info(f'response data: {response.status_code}  {response.content}')
        return False, []
    return True, response.json()


def convert_name(s: str) -> str:
    s = s.lower().strip()
    re_sub = re.sub('[^\w]+', '_', s)
    re_sub = re.sub('_{2,}', '_', re_sub)
    re_sub = re_sub[:-1] if re_sub and re_sub[-1] == '_' else re_sub
    return re_sub


def convert_str_into_datetime(s: str) -> datetime:
    return datetime.datetime.strptime(s, FRM_DATETIME)


def change_last_datetime(date_json):
    datetime_end = convert_str_into_datetime(date_json[KEY_DATE_END])
    date_json[KEY_DATE_END] = (datetime_end + datetime.timedelta(days=1)).strftime(FRM_DATETIME)
    date_json[KEY_DATE_START] = datetime_end.replace(second=0).strftime(FRM_DATETIME)
    return date_json


def save_last_datetime(date_json):
    with open(CACHE_FILE_DATETIME, 'w') as json_file:
        json.dump(date_json, json_file)


def is_date(logger, string: str) -> bool:
    try:
        datetime.datetime.strptime(string, FRM_DATETIME)
    except ValueError:
        logger.error(f'incorrect data format {string}, should be {FRM_DATETIME}')
        return False
    return True


def validate_json_frm(logger, data_json) -> bool:
    if not all(k in data_json for k in (KEY_DATE_END, KEY_DATE_START)):
        return False
    if not all(is_date(logger, string) for string in data_json.values()):
        return False
    return True


def pre_validate_global_variable(logger):
    if not CACHE_FILE_DATETIME:
        variable_msg = {
            'cache_file_datetime': CACHE_FILE_DATETIME,
        }

        msg = """Error some variable empty or aren't correct:
                CACHE_FILE_DATETIME - {cache_file_datetime}
                """

        logger.error(msg.format(**variable_msg))
        exit(msg.format(**variable_msg))


def post_validate_global_variable(logger):
    if not (BASE_URL and API_KEY and CACHE_FILE_DATETIME and FRM_DATETIME and RES_DIR):
        variable_msg = {
            'base_url': BASE_URL,
            'api_key': 'XXXXXXXXXXXXX',
            'cache_file_datetime': CACHE_FILE_DATETIME,
            'frm_datetime': FRM_DATETIME,
            'res_dir': RES_DIR
        }

        msg = """Error some variable empty or aren't correct:
        URL - {base_url}
        API_KEY - {api_key}
        CACHE_FILE_DATETIME - {cache_file_datetime}
        FRM_DATETIME_FILTER - {frm_datetime}
        RES_DIR  - {res_dir}
        """

        logger.error(msg.format(**variable_msg))
        variable_msg['api_key'] = API_KEY
        exit(msg.format(**variable_msg))

    msg_err = 'error:'
    if not os.path.isdir(RES_DIR):
        try:
            os.mkdir(RES_DIR)
        except OSError as e:
            logger.error(f'{msg_err} to try create dir for path: {RES_DIR} error: {e}')
            exit(f'{msg_err} to try create dir for path: {RES_DIR}')
    elif not os.access(RES_DIR, os.W_OK):
        logger.error(f'{msg_err} this dir not have writeable rule: {RES_DIR}')
        exit(f'{msg_err} this dir not have writeable rule: {RES_DIR}')

    if USE_DATETIME and not is_date(logger, USE_DATETIME):
        logger.error(f'{msg_err} not correct variable {USE_DATETIME} for this format {FRM_DATETIME}')
        exit(f'{msg_err} not correct variable {USE_DATETIME} for this format {FRM_DATETIME}')


def save_json_storage(logger, list_storage: list, start_time: str, end_time: str):
    get_date = lambda s: s.split('T')[0]

    name_file = '__'.join(map(get_date, (start_time, end_time)))
    path = os.path.join(RES_DIR, '.'.join((name_file, 'json')))

    logger.info(f'dump json start_time {start_time} into {end_time} save into path {path}')
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(list_storage, f, ensure_ascii=False, indent=4)


def run_query_apis(logger):
    kwargs = dict()
    mapping_list = list()
    storage_json = list()
    start_datetime_json = None
    logger = logger
    logger.info(f'current last time: {LAST_DATETIME}')

    if MAPPING:
        status_mapping, mapping_list = get_mapping_api(logger)
        logger.info(f'information mapping list {mapping_list}')
        status_mapping or exit('error: to try get sigma mapping')

        if MAPPING not in mapping_list:
            logger.info(f'this mapping "{MAPPING}" not in list {mapping_list}')
            exit(f'error: this mapping "{MAPPING}" not in list {mapping_list}')
        else:
            kwargs['mapping_name'] = MAPPING

    if USE_FILTER_CLIENT_SIEM_TYPE:
        kwargs['client_siem_type'] = USE_FILTER_CLIENT_SIEM_TYPE

    while True:
        if not os.path.isfile(CACHE_FILE_DATETIME) or os.path.isfile(CACHE_FILE_DATETIME) \
                and not os.stat(CACHE_FILE_DATETIME).st_size:

            date_filter = dict.fromkeys((KEY_DATE_END, KEY_DATE_START),
                                        USE_DATETIME or FIRST_DATETIME.strftime(FRM_DATETIME))
            date_filter = change_last_datetime(date_filter)
        else:
            with open(CACHE_FILE_DATETIME) as json_file:
                date_filter = json.load(json_file)

            if not validate_json_frm(logger, date_filter):
                logger.error(f'not validate format file {CACHE_FILE_DATETIME} json-frm: {date_filter}')
                raise Exception(f'not validate file {CACHE_FILE_DATETIME}, need remove this file {CACHE_FILE_DATETIME}')

        logger.info(f'show date filter: {date_filter}')
        kwargs.update(**date_filter)
        _, context = query_api(logger, **kwargs)

        if not start_datetime_json:
            start_datetime_json = date_filter[KEY_DATE_START]
        if len(storage_json) < MAX_ELEMENT_STORAGE_JSON:
            storage_json.append(context)
        else:
            save_json_storage(logger,
                              storage_json,
                              start_time=start_datetime_json,
                              end_time=date_filter[KEY_DATE_END])
            start_datetime_json = None
            storage_json = list()

        datetime_obj = convert_str_into_datetime(date_filter[KEY_DATE_END])
        if datetime_obj >= LAST_DATETIME:
            date_filter[KEY_DATE_END] = LAST_DATETIME.strftime(FRM_DATETIME)
            date_filter[KEY_DATE_START] = (LAST_DATETIME.replace(second=0) -
                                           datetime.timedelta(minutes=5)).strftime(FRM_DATETIME)
            save_last_datetime(date_filter)
            logger.info(f'finish script: {datetime_obj} >= {LAST_DATETIME}')
            if storage_json:
                save_json_storage(logger,
                                  storage_json,
                                  start_time=date_filter[KEY_DATE_END],
                                  end_time='nowT')
            return
        date_filter = change_last_datetime(date_filter)
        save_last_datetime(date_filter)


def valid_str_date(s: str) -> str or None:
    first_date = datetime.datetime(2018, 4, 17)  # First date for updated sigma
    now_date = LAST_DATETIME.replace(second=0)
    try:
        input_date = datetime.datetime.strptime(s, '%Y-%m-%d')
        if now_date <= input_date:
            raise AttributeError
        elif input_date < first_date:
            input_date = first_date
        return input_date.strftime(FRM_DATETIME)
    except ValueError:
        msg = "Not a valid date: '{}'".format(s)
        raise argparse.ArgumentTypeError(msg)
    except AttributeError:
        msg = "Not a valid date, this future date: '{}'".format(s)
        raise argparse.ArgumentTypeError(msg)


def str2bool(v):
    if isinstance(v, bool):
        return v
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')


if __name__ == '__main__':
    logger = Logger('run_script')
    pre_validate_global_variable(logger)

    parser = argparse.ArgumentParser(
        description=f'List commands for "{os.path.basename(__file__)}" script.')
    parser.add_argument('--debug-mode',
                        type=str2bool,
                        nargs='?',
                        const=True,
                        default=False,
                        help='activate debug mode in console')
    parser.add_argument('-d', '--path-dir',
                        type=str,
                        help='full path to directory')
    parser.add_argument('-k', '--api-key',
                        type=str,
                        help='secret api key')
    # parser.add_argument('-f', '--format-file',
    #                     default='txt',
    #                     choices=list(FRM_FILES),
    #                     help='save format file:')
    parser.add_argument('-s',
                        '--startdate',
                        help='the start date - format: YYYY-MM-DD',
                        required=False,
                        type=valid_str_date)
    parser.add_argument('-m',
                        '--mapping-field',
                        type=str,
                        help='get sigma mapping field rule')
    parser.add_argument('-v',
                        '---filter-sigma-type',
                        choices=list(FILTER_CLIENT_SIEM_TYPE),
                        help='filter sigma type')

    args = parser.parse_args()
    DEBUG = args.debug_mode if args.debug_mode else DEBUG
    RES_DIR = args.path_dir if args.path_dir else RES_DIR
    USE_FILTER_CLIENT_SIEM_TYPE = args.filter_sigma_type if args.filter_sigma_type else USE_FILTER_CLIENT_SIEM_TYPE
    API_KEY = args.api_key if args.api_key else API_KEY
    MAPPING = args.mapping_field if args.mapping_field else MAPPING

    if args.startdate:
        USE_DATETIME = args.startdate
        if os.path.exists(CACHE_FILE_DATETIME):
            try:
                os.remove(CACHE_FILE_DATETIME)
            except:
                logger.error(f"can't remove file {CACHE_FILE_DATETIME}")
                exit(f"error: can't remove file {CACHE_FILE_DATETIME}")

    post_validate_global_variable(logger)
    run_query_apis(logger)
